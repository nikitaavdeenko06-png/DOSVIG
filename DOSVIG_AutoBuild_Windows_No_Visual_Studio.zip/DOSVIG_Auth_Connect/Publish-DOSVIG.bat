﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ================================================
echo             DOSVIG Portable Publisher
echo ================================================
echo.
where dotnet >nul 2>nul
if errorlevel 1 (
  echo ERROR: .NET SDK was not found.
  echo Install the .NET 8 SDK or Visual Studio workload ".NET desktop development".
  echo Then run this file again.
  pause
  exit /b 1
)
dotnet --list-sdks | findstr /b "8." >nul
if errorlevel 1 (
  echo WARNING: .NET 8 SDK not detected. The project targets net8.0-windows.
  echo Install .NET 8 SDK, then try again.
  pause
  exit /b 1
)
echo Publishing self-contained Windows x64 single-file app...
dotnet publish "DOSVIGLauncher.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -p:DebugType=None -p:DebugSymbols=false
if errorlevel 1 (
  echo.
  echo PUBLISH FAILED. Copy the full error text and send it to ChatGPT.
  pause
  exit /b 1
)
if not exist "release" mkdir "release"
if exist "bin\Release\net8.0-windows\win-x64\publish\DOSVIGLauncher.exe" (
  copy /y "bin\Release\net8.0-windows\win-x64\publish\DOSVIGLauncher.exe" "release\DOSVIG.exe" >nul
) else (
  echo Publish finished, but expected EXE was not found.
  echo Check bin\Release\net8.0-windows\win-x64\publish\
  pause
  exit /b 1
)
echo.
echo SUCCESS! Portable app created:
echo %CD%\release\DOSVIG.exe
echo.
echo Test DOSVIG.exe on your own PC before sharing it.
echo User data and Minecraft files are stored separately in AppData.
pause
