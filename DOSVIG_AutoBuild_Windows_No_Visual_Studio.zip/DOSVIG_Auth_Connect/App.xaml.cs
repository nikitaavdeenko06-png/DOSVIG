using System.Windows;
namespace DOSVIGLauncher;
public partial class App : Application { }
