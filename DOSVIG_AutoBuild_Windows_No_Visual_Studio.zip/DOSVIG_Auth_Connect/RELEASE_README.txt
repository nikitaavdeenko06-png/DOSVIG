DOSVIG — PORTABLE WINDOWS RELEASE KIT
====================================

WHAT THIS IS
This archive contains the current DOSVIG WPF project and a script that publishes it as a self-contained Windows x64 single-file EXE. The EXE is intended to run on Windows 10/11 x64 without asking the player to install .NET separately.

HOW TO CREATE DOSVIG.exe
1. Extract this entire ZIP to a normal folder, for example Desktop\DOSVIG.
2. Install Visual Studio with the ".NET desktop development" workload and the .NET 8 SDK if not already installed.
3. Open the folder DOSVIG_Auth_Connect.
4. Double-click Publish-DOSVIG.bat.
5. Wait for publishing to finish. The result should be:
   DOSVIG_Auth_Connect\release\DOSVIG.exe
6. Run that EXE and test it before sharing it with anyone.

IMPORTANT
- This kit does not contain a prebuilt EXE. This environment does not have the Windows .NET SDK needed to build/test a WPF Windows app. The BAT file builds the EXE on your Windows PC.
- The published app is self-contained for .NET, but Minecraft files still need to download on first launch. Internet is required for downloading game assets and connecting to servers.
- The current DOSVIG project is a prototype. Test Microsoft authentication, offline nicknames, server join, and connection failures before public release.
- Offline nicknames work only on servers configured to allow offline-mode. Online-mode servers require official Minecraft/Microsoft authentication.
- Windows SmartScreen may warn users because the app is not code-signed. Do not tell players to ignore security warnings blindly; publish only builds you trust.
- Keep the project source and a backup ZIP. Do not overwrite your known-working copy.

FREE DISTRIBUTION (LATER)
A free first option is GitHub Releases: create a public repository, upload the source project, and attach release\DOSVIG.exe to a release. GitHub hosting is free for public repositories, but you should review its current terms and limits. A custom .com domain is normally not free; you can start with the GitHub Releases download page instead.

BEFORE PUBLIC RELEASE CHECKLIST
[ ] Build succeeds with no errors
[ ] App opens on a clean Windows account/PC
[ ] First Minecraft install completes
[ ] Server selection passes the correct IP and port
[ ] Wrong IP / offline server produces a clear error and returns focus to DOSVIG
[ ] Microsoft authentication tested only with official flow
[ ] No passwords or tokens are written to logs
[ ] Add a version number and release notes
[ ] Scan the final EXE with Windows Security
