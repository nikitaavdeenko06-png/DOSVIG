﻿using System;
using System.Collections.Generic;
using System.Linq;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.Auth.Microsoft;
using CmlLib.Core.ProcessBuilder;
using DOSVIGLauncher.Models;
using DOSVIGLauncher.Services;
using System.IO;
using System.Text.Json;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DOSVIGLauncher;

public partial class MainWindow : Window
{
 private readonly DosvigAccountStore accountStore=new();
 private readonly List<ServerInfo> servers=new();
 private readonly string dataFolder=global::System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),"DOSVIGLauncher");
 private string ServerFile=>global::System.IO.Path.Combine(dataFolder,"servers.json");
 private ContentControl host=new(); private Button serversNav=new(), accountNav=new(), msHeader=new();
 private TextBlock? msStatus,dosvigStatus,count,launchStatus; private TextBox? username,search,minecraftNick; private PasswordBox? password,confirmation; private WrapPanel? cards;
 private JELoginHandler? loginHandler; private MSession? minecraftSession; private string? minecraftUser,dosvigUser; private bool busy;
 private static Brush B(string h)=>(Brush)new BrushConverter().ConvertFromString(h)!;
 private static TextBlock T(string s,double size=14,bool bold=false,Brush? fg=null)=>new(){Text=s,FontSize=size,FontWeight=bold?FontWeights.Bold:FontWeights.Normal,Foreground=fg??B("#FAF7FF"),TextWrapping=TextWrapping.Wrap};
 private static Button Btn(string text,bool primary=false)=>new(){Content=text,Background=primary?B("#913ED0"):B("#1A1224"),BorderBrush=primary?B("#B76AFF"):B("#30213D"),Padding=new Thickness(13,10,13,10)};
 private static Border Box(UIElement child,double padding=19,string bg="#130E1B")=>new(){Child=child,Padding=new Thickness(padding),Background=B(bg),BorderBrush=B("#30213D"),BorderThickness=new Thickness(1),CornerRadius=new CornerRadius(15)};
 public MainWindow(){InitializeComponent();BuildHeader();LoadServers();ShowAuthPage();}
 private void BuildHeader(){var h=new Border{Background=B("#0B0811"),BorderBrush=B("#25182F"),BorderThickness=new Thickness(0,0,0,1),Padding=new Thickness(25,0,25,0)};var g=new Grid();g.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});g.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});g.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});var logo=new StackPanel{Orientation=Orientation.Horizontal,VerticalAlignment=VerticalAlignment.Center};logo.Children.Add(T("DOSVIG",25,true));logo.Children.Add(T(".",28,true,B("#AD63F7")));g.Children.Add(logo);var nav=new StackPanel{Orientation=Orientation.Horizontal,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,10,0)};serversNav=Btn("Сервера");serversNav.Margin=new Thickness(0,0,6,0);serversNav.Click+=(_,_)=>ShowServersPage();accountNav=Btn("Аккаунт DOSVIG");accountNav.Click+=(_,_)=>ShowAuthPage();nav.Children.Add(serversNav);nav.Children.Add(accountNav);Grid.SetColumn(nav,1);g.Children.Add(nav);msHeader=Btn("Войти через Microsoft",true);msHeader.Click+=MicrosoftLogin_Click;Grid.SetColumn(msHeader,2);g.Children.Add(msHeader);h.Child=g;Grid.SetRow(h,0);Root.Children.Add(h);host=new ContentControl();Grid.SetRow(host,1);Root.Children.Add(host);}
 private void LoadServers()
  {
   try
   {
    global::System.IO.Directory.CreateDirectory(dataFolder);
    if(global::System.IO.File.Exists(ServerFile))
    {
     var loaded=JsonSerializer.Deserialize<List<ServerInfo>>(global::System.IO.File.ReadAllText(ServerFile)) ?? new List<ServerInfo>();
     // Remove demo/example entries left by previous DOSVIG builds.
     var realServers=loaded.Where(s => s != null && !s.IsDemo
      && !string.IsNullOrWhiteSpace(s.Name) && !string.IsNullOrWhiteSpace(s.Ip)
      && !s.Ip.EndsWith(".example",StringComparison.OrdinalIgnoreCase)
      && !s.Ip.EndsWith(".test",StringComparison.OrdinalIgnoreCase)
      && !s.Name.StartsWith("Пример ",StringComparison.OrdinalIgnoreCase))
      .ToList();
     servers.AddRange(realServers);
     if(realServers.Count != loaded.Count) SaveServers();
     return;
    }
   }
   catch { }
   // Start with an empty catalogue; users add real servers themselves.
   SaveServers();
  }
  private void SaveServers(){try{global::System.IO.Directory.CreateDirectory(dataFolder);global::System.IO.File.WriteAllText(ServerFile,JsonSerializer.Serialize(servers,new JsonSerializerOptions{WriteIndented=true}));}catch(Exception ex){MessageBox.Show("Не удалось сохранить сервера: "+ex.Message,"DOSVIG",MessageBoxButton.OK,MessageBoxImage.Warning);}}
 private void ShowAuthPage(){var root=new StackPanel{Margin=new Thickness(27,22,27,25)};var scroll=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};var intro=new StackPanel();intro.Children.Add(T("ВАШ АККАУНТ",10,true,B("#D4A5FF")));intro.Children.Add(T("Добро пожаловать в DOSVIG",36,true));intro.Children.Add(T("Выбери игровой ник. Microsoft и DOSVIG ID не обязательны для серверов, разрешающих вход по нику.",14,false,B("#B0A4BD")));var ib=Box(intro,22,"#211132");ib.Margin=new Thickness(0,0,0,16);root.Children.Add(ib);
 var cols=new Grid();cols.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});cols.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});
 var ms=new StackPanel();ms.Children.Add(T("01 / MICROSOFT",10,true,B("#D4A5FF")));ms.Children.Add(T("Minecraft-аккаунт",23,true));ms.Children.Add(T("Необязательно. Нужен для серверов, которые требуют лицензионную авторизацию. Пароль вводится только на официальной странице Microsoft.",13,false,B("#B0A4BD")));msStatus=T(minecraftUser is null?"Minecraft не подключён":"Подключено: "+minecraftUser,12,true,minecraftUser is null?B("#B0A4BD"):B("#86EFAC"));msStatus.Margin=new Thickness(0,14,0,12);ms.Children.Add(msStatus);var mbtn=Btn(minecraftUser is null?"Войти через Microsoft":"Microsoft ✓",true);mbtn.HorizontalAlignment=HorizontalAlignment.Left;mbtn.Click+=MicrosoftLogin_Click;ms.Children.Add(mbtn);ms.Children.Add(T("Нужны интернет, Minecraft: Java Edition и доступный Xbox-профиль.",11,false,B("#B0A4BD")));var mb=Box(ms,20,"#130C1D");mb.Margin=new Thickness(0,0,8,0);cols.Children.Add(mb);
 var ds=new StackPanel();ds.Children.Add(T("02 / DOSVIG ID",10,true,B("#D4A5FF")));ds.Children.Add(T("Аккаунт платформы",23,true));ds.Children.Add(T("Локальный логин DOSVIG. В этой демоверсии аккаунты хранятся на этом компьютере, не в интернете.",13,false,B("#B0A4BD")));ds.Children.Add(T("Логин",12,false,B("#E0D6E8")));username=new TextBox{Height=37,Margin=new Thickness(0,0,0,8)};ds.Children.Add(username);ds.Children.Add(T("Пароль (минимум 8 символов)",12,false,B("#E0D6E8")));password=new PasswordBox{Height=37,Margin=new Thickness(0,0,0,8)};ds.Children.Add(password);ds.Children.Add(T("Повтори пароль при регистрации",12,false,B("#E0D6E8")));confirmation=new PasswordBox{Height=37,Margin=new Thickness(0,0,0,11)};ds.Children.Add(confirmation);var actions=new WrapPanel();var login=Btn("Войти в DOSVIG",true);login.Margin=new Thickness(0,0,7,7);login.Click+=DosvigLogin_Click;actions.Children.Add(login);var register=Btn("Создать аккаунт");register.Margin=new Thickness(0,0,7,7);register.Click+=DosvigRegister_Click;actions.Children.Add(register);ds.Children.Add(actions);dosvigStatus=T(dosvigUser is null?"DOSVIG ID: гость":"Вход выполнен: "+dosvigUser,12,true,dosvigUser is null?B("#B0A4BD"):B("#86EFAC"));dosvigStatus.Margin=new Thickness(0,8,0,0);ds.Children.Add(dosvigStatus);var db=Box(ds,20,"#130C1D");db.Margin=new Thickness(8,0,0,0);Grid.SetColumn(db,1);cols.Children.Add(db);root.Children.Add(cols);
 var go=Btn("Открыть каталог серверов →",true);go.HorizontalAlignment=HorizontalAlignment.Left;go.Margin=new Thickness(0,16,0,0);go.Click+=(_,_)=>ShowServersPage();root.Children.Add(go);host.Content=scroll;SetNav(false);UpdateHeader();}
 private async void MicrosoftLogin_Click(object sender,RoutedEventArgs e){if(busy)return;busy=true;msHeader.IsEnabled=false;msHeader.Content="Подключение...";if(msStatus!=null)msStatus.Text="Открывается вход Microsoft/Xbox...";try{global::System.IO.Directory.CreateDirectory(dataFolder);loginHandler??=new JELoginHandlerBuilder().WithAccountManager(global::System.IO.Path.Combine(dataFolder,"cml_accounts.json")).Build();minecraftSession=await loginHandler.Authenticate();minecraftUser=minecraftSession.Username;if(msStatus!=null){msStatus.Text="Подключено: "+minecraftUser;msStatus.Foreground=B("#86EFAC");}MessageBox.Show("Minecraft-профиль подключён: "+minecraftUser,"DOSVIG",MessageBoxButton.OK,MessageBoxImage.Information);}catch(Exception ex){if(msStatus!=null){msStatus.Text="Не удалось войти — проверь Xbox, Minecraft Java и интернет.";msStatus.Foreground=B("#FF9B9B");}MessageBox.Show("Microsoft-вход не завершился. На аккаунте должна быть Minecraft: Java Edition, интернет должен работать и Xbox-профиль не должен быть ограничен.\n\n"+ex.Message,"DOSVIG — Microsoft",MessageBoxButton.OK,MessageBoxImage.Warning);}finally{busy=false;msHeader.IsEnabled=true;UpdateHeader();}}
 private void DosvigRegister_Click(object sender,RoutedEventArgs e){if(username==null||password==null||confirmation==null)return;var r=new DosvigAccountStore().Register(username.Text,password.Password,confirmation.Password);HandleAccount(r.Success,r.Message,r.Username);}
 private void DosvigLogin_Click(object sender,RoutedEventArgs e){if(username==null||password==null)return;var r=new DosvigAccountStore().Login(username.Text,password.Password);HandleAccount(r.Success,r.Message,r.Username);}
 private void HandleAccount(bool ok,string msg,string? user){if(ok)dosvigUser=user;if(dosvigStatus!=null){dosvigStatus.Text=msg;dosvigStatus.Foreground=ok?B("#86EFAC"):B("#FF9B9B");}MessageBox.Show(msg,"DOSVIG ID",MessageBoxButton.OK,ok?MessageBoxImage.Information:MessageBoxImage.Warning);UpdateHeader();}
 private void UpdateHeader(){if(accountNav!=null)accountNav.Content=dosvigUser==null?"Аккаунт DOSVIG":"DOSVIG: "+dosvigUser;if(msHeader!=null)msHeader.Content=minecraftUser==null?"Войти через Microsoft":"Microsoft ✓";}
 private void SetNav(bool servers){serversNav.Background=servers?B("#21142D"):B("#1A1224");accountNav.Background=servers?B("#1A1224"):B("#21142D");}
 private void ShowServersPage(){var root=new StackPanel{Margin=new Thickness(28,23,28,25)};var scroll=new ScrollViewer{VerticalScrollBarVisibility=ScrollBarVisibility.Auto,Content=root};var heroGrid=new Grid();heroGrid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});heroGrid.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(165)});var copy=new StackPanel{VerticalAlignment=VerticalAlignment.Center};copy.Children.Add(T("MINECRAFT SERVER PLATFORM",10,true,B("#D4A5FF")));copy.Children.Add(T("Твой мир.",43,true));copy.Children.Add(T("Твои правила.",43,true,B("#D18BFF")));copy.Children.Add(T("Выбирай сервер и подключайся по IP.",14,false,B("#B0A4BD")));heroGrid.Children.Add(copy);var logoText=T("D",92,true);logoText.HorizontalAlignment=HorizontalAlignment.Center;logoText.VerticalAlignment=VerticalAlignment.Center;var logo=new Border{Width=140,Height=140,CornerRadius=new CornerRadius(29),Background=B("#813ABD"),BorderBrush=B("#D4A5FF"),BorderThickness=new Thickness(1),Child=logoText,HorizontalAlignment=HorizontalAlignment.Center,VerticalAlignment=VerticalAlignment.Center};Grid.SetColumn(logo,1);heroGrid.Children.Add(logo);var hb=Box(heroGrid,22,"#130C1D");hb.Margin=new Thickness(0,0,0,19);root.Children.Add(hb);var row=new Grid{Margin=new Thickness(0,0,0,12)};row.ColumnDefinitions.Add(new ColumnDefinition{Width=new GridLength(1,GridUnitType.Star)});row.ColumnDefinitions.Add(new ColumnDefinition{Width=GridLength.Auto});search=new TextBox{Height=41,Margin=new Thickness(0,0,8,0)};search.TextChanged+=(_,_)=>RenderCards();row.Children.Add(search);var acc=Btn("Аккаунты");acc.Click+=(_,_)=>ShowAuthPage();Grid.SetColumn(acc,1);row.Children.Add(acc);root.Children.Add(row);var nickPanel=new StackPanel{Margin=new Thickness(0,0,0,10)};nickPanel.Children.Add(T("ИГРОВОЙ НИК MINECRAFT",11,true,B("#D4A5FF")));nickPanel.Children.Add(T("Для серверов без лицензированной авторизации введи ник (3–16 символов: латинские буквы, цифры и _). Пароль от сервера вводится уже в игре.",12,false,B("#B0A4BD")));minecraftNick=new TextBox{Height=41,MaxLength=16,Text=LoadMinecraftNick(),Margin=new Thickness(0,7,0,0)};minecraftNick.TextChanged+=(_,_)=>SaveMinecraftNick();nickPanel.Children.Add(minecraftNick);root.Children.Add(Box(nickPanel,13,"#130C1D"));count=T("",12,false,B("#B0A4BD"));root.Children.Add(count);cards=new WrapPanel{Margin=new Thickness(0,11,0,0)};root.Children.Add(cards);launchStatus=T("Добавь настоящий сервер с IP, портом и точной версией.",12,false,B("#B0A4BD"));launchStatus.Margin=new Thickness(0,13,0,9);root.Children.Add(Box(launchStatus,12));var add=Btn("＋ Добавить сервер",true);add.HorizontalAlignment=HorizontalAlignment.Left;add.Click+=AddServer_Click;root.Children.Add(add);host.Content=scroll;SetNav(true);RenderCards();}
 private string NickFile=>global::System.IO.Path.Combine(dataFolder,"minecraft-nick.txt");
 private string LoadMinecraftNick(){try{global::System.IO.Directory.CreateDirectory(dataFolder);if(global::System.IO.File.Exists(NickFile))return global::System.IO.File.ReadAllText(NickFile).Trim();}catch{}return "";}
 private void SaveMinecraftNick(){try{global::System.IO.Directory.CreateDirectory(dataFolder);global::System.IO.File.WriteAllText(NickFile,minecraftNick?.Text.Trim()??"");}catch{}}
 private static bool IsValidMinecraftNick(string nick){if(nick.Length<3||nick.Length>16)return false;foreach(char c in nick)if(!(c>='A'&&c<='Z'||c>='a'&&c<='z'||c>='0'&&c<='9'||c=='_'))return false;return true;}
 private void RenderCards(){if(cards==null)return;string q=search?.Text.Trim()??"";var found=servers.Where(s=>(s.Name+" "+s.Ip+" "+s.Mode+" "+s.Version).Contains(q,StringComparison.OrdinalIgnoreCase)).ToList();cards.Children.Clear();if(count!=null)count.Text=$"{found.Count} сервер(ов)";foreach(var s in found){var stack=new StackPanel();var it=T(s.Icon,40,true);it.HorizontalAlignment=HorizontalAlignment.Center;it.VerticalAlignment=VerticalAlignment.Center;stack.Children.Add(new Border{Height=100,CornerRadius=new CornerRadius(10),Background=B(s.Accent),Child=it});var title=T(s.Name,15,true);title.Margin=new Thickness(0,10,0,4);stack.Children.Add(title);stack.Children.Add(T($"{s.Ip}:{s.Port}",10,false,B("#B0A4BD")));stack.Children.Add(T($"{s.Mode} • {s.Version}",10,false,B("#D0C5DA")));var play=Btn("Играть ↗",true);play.Margin=new Thickness(0,11,0,0);play.HorizontalAlignment=HorizontalAlignment.Stretch;play.Click+=async(_,_)=>await LaunchServerAsync(s,play);stack.Children.Add(play);var card=Box(stack,10);card.Width=240;card.Margin=new Thickness(0,0,12,12);cards.Children.Add(card);}if(found.Count==0)cards.Children.Add(T("Ничего не найдено.",14,false,B("#B0A4BD")));}
 private async Task LaunchServerAsync(ServerInfo server,Button button){if(server.IsDemo||server.Ip.EndsWith(".test",StringComparison.OrdinalIgnoreCase)||server.Ip.EndsWith(".example",StringComparison.OrdinalIgnoreCase)){MessageBox.Show("Это пример карточки. Нажми «Добавить сервер» и введи настоящий IP/домен, порт и точную версию Minecraft Java.","DOSVIG",MessageBoxButton.OK,MessageBoxImage.Information);return;}string nick=minecraftNick?.Text.Trim()??"";if(!IsValidMinecraftNick(nick)){MessageBox.Show("Введи игровой ник длиной 3–16 символов. Разрешены английские буквы, цифры и знак _.","DOSVIG",MessageBoxButton.OK,MessageBoxImage.Warning);minecraftNick?.Focus();return;}if(busy)return;busy=true;button.IsEnabled=false;try{SaveMinecraftNick();string game=global::System.IO.Path.Combine(dataFolder,"minecraft");global::System.IO.Directory.CreateDirectory(game);var launcher=new MinecraftLauncher(new MinecraftPath(game));launcher.FileProgressChanged+=(_,a)=>Dispatcher.Invoke(()=>{if(launchStatus!=null)launchStatus.Text=$"Загружаю {a.Name} ({a.ProgressedTasks}/{a.TotalTasks})";});await launcher.InstallAsync(server.Version);if(launchStatus!=null)launchStatus.Text="Файлы загружены. Запускаю Minecraft и подключаюсь...";MSession session=minecraftSession??MSession.CreateOfflineSession(nick);var proc=await launcher.BuildProcessAsync(server.Version,new MLaunchOption{Session=session,ServerIp=server.Ip,ServerPort=server.Port,MaximumRamMb=2048,GameLauncherName="DOSVIG",GameLauncherVersion="0.1"});
// Capture log offset BEFORE Minecraft starts so fast failures cannot be missed.
string logFile=global::System.IO.Path.Combine(game,"logs","latest.log");
long logStartPosition=0;
try{if(global::System.IO.File.Exists(logFile))logStartPosition=new FileInfo(logFile).Length;}catch{}
proc.Start();
if(launchStatus!=null)launchStatus.Text=$"Minecraft запущен. Подключение к {server.Ip}:{server.Port}...";
// Monitor only log lines written by this launch.
_ = MonitorConnectionAsync(proc,logFile,server,logStartPosition);
}catch(Exception ex){MessageBox.Show("Не получилось запустить Minecraft. Проверь IP, версию, интернет и свободное место.\n\n"+ex,"DOSVIG",MessageBoxButton.OK,MessageBoxImage.Error);if(launchStatus!=null)launchStatus.Text="Ошибка запуска.";}finally{busy=false;button.IsEnabled=true;}}

 private async Task MonitorConnectionAsync(Process proc,string logFile,ServerInfo server,long position)
 {
  bool sawConnectionAttempt=false;
  string pending="";
  string[] failureMarkers={
   "Failed to connect to the server", "Connection refused", "Connection timed out",
   "Unknown host", "java.net.UnknownHostException", "java.net.ConnectException",
   "java.net.SocketTimeoutException", "multiplayer.disconnect", "Disconnected",
   "Connection closed", "Internal Exception", "ReadTimeoutException", "Connection reset"
  };
  // Observe new log content for up to 10 minutes. Keep DOSVIG alive and terminate only this launched game process tree on failure.
  for(int i=0;i<600;i++)
  {
   await Task.Delay(500);
   try
   {
    if(proc.HasExited)return;
    if(!global::System.IO.File.Exists(logFile))continue;
    using(var stream=new FileStream(logFile,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete))
    {
     if(stream.Length<position)position=0; // latest.log was rotated
     stream.Seek(position,SeekOrigin.Begin);
     using var reader=new StreamReader(stream);
     string fresh=await reader.ReadToEndAsync();
     position=stream.Position;
     if(string.IsNullOrEmpty(fresh))continue;
     pending+=fresh;
     if(pending.Contains("Connecting to",StringComparison.OrdinalIgnoreCase) || pending.Contains("Connecting...",StringComparison.OrdinalIgnoreCase) || pending.Contains("Connecting to server",StringComparison.OrdinalIgnoreCase))sawConnectionAttempt=true;
     if(sawConnectionAttempt && failureMarkers.Any(marker=>pending.Contains(marker,StringComparison.OrdinalIgnoreCase)))
     {
      try{if(!proc.HasExited)proc.Kill(true);}catch{}
      await Dispatcher.InvokeAsync(() =>
      {
       try{if(!IsVisible)Show();WindowState=WindowState.Normal;Topmost=true;Activate();Topmost=false;}catch{}
       if(launchStatus!=null)launchStatus.Text="Подключение не удалось. Ты вернулся в DOSVIG.";
       MessageBox.Show($"Не удалось подключиться к серверу «{server.Name}». Minecraft закрыт, DOSVIG снова на переднем плане. Проверь IP, порт, версию и доступность сервера.","DOSVIG — ошибка подключения",MessageBoxButton.OK,MessageBoxImage.Warning);
      });
      return;
     }
     if(pending.Length>16000)pending=pending[^8000..];
    }
   }
   catch { /* Minecraft may be creating or rotating its log. */ }
  }
 }
 private void AddServer_Click(object sender,RoutedEventArgs e){var d=new AddServerDialog{Owner=this};if(d.ShowDialog()==true&&d.ResultServer!=null){servers.Insert(0,d.ResultServer);SaveServers();ShowServersPage();MessageBox.Show("Сервер сохранён на этом компьютере.","DOSVIG",MessageBoxButton.OK,MessageBoxImage.Information);}}
}
