using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
namespace DOSVIGLauncher.Services;
public sealed class DosvigAccountStore {
 private sealed class AccountRecord { public string Username { get; set; } = ""; public string Salt { get; set; } = ""; public string PasswordHash { get; set; } = ""; }
 public sealed record AccountResult(bool Success, string Message, string? Username = null);
 private readonly string _folder = global::System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DOSVIGLauncher");
 private string FilePath => global::System.IO.Path.Combine(_folder, "dosvig-accounts.json");
 private List<AccountRecord> Load() { global::System.IO.Directory.CreateDirectory(_folder); if (!global::System.IO.File.Exists(FilePath)) return new(); return JsonSerializer.Deserialize<List<AccountRecord>>(global::System.IO.File.ReadAllText(FilePath)) ?? new(); }
 private void Save(List<AccountRecord> list) { global::System.IO.Directory.CreateDirectory(_folder); global::System.IO.File.WriteAllText(FilePath, JsonSerializer.Serialize(list, new JsonSerializerOptions { WriteIndented = true })); }
 public AccountResult Register(string username, string password, string confirmation) {
  username = username.Trim();
  if (username.Length < 3 || username.Length > 24) return new(false, "Логин должен содержать от 3 до 24 символов.");
  if (username.Any(c => !(char.IsLetterOrDigit(c) || c == '_' || c == '-'))) return new(false, "В логине разрешены буквы, цифры, _ и -.");
  if (password.Length < 8) return new(false, "Пароль DOSVIG должен быть не короче 8 символов.");
  if (password != confirmation) return new(false, "Пароли не совпадают.");
  try { var list=Load(); if(list.Any(a=>a.Username.Equals(username,StringComparison.OrdinalIgnoreCase))) return new(false,"Этот логин уже зарегистрирован на этом компьютере."); byte[] salt=RandomNumberGenerator.GetBytes(16); byte[] hash=Rfc2898DeriveBytes.Pbkdf2(password,salt,210_000,HashAlgorithmName.SHA256,32); list.Add(new AccountRecord{Username=username,Salt=Convert.ToBase64String(salt),PasswordHash=Convert.ToBase64String(hash)}); Save(list); return new(true,"Аккаунт DOSVIG создан на этом компьютере.",username); }
  catch(Exception ex) { return new(false,"Не удалось сохранить аккаунт DOSVIG: "+ex.Message); }
 }
 public AccountResult Login(string username,string password) {
  try { var account=Load().FirstOrDefault(a=>a.Username.Equals(username.Trim(),StringComparison.OrdinalIgnoreCase)); if(account is null)return new(false,"Аккаунт не найден на этом компьютере."); byte[] salt=Convert.FromBase64String(account.Salt); byte[] expected=Convert.FromBase64String(account.PasswordHash); byte[] actual=Rfc2898DeriveBytes.Pbkdf2(password,salt,210_000,HashAlgorithmName.SHA256,32); if(!CryptographicOperations.FixedTimeEquals(expected,actual))return new(false,"Неверный логин или пароль."); return new(true,"Вход в DOSVIG выполнен.",account.Username); }
  catch(Exception ex){return new(false,"Не удалось проверить аккаунт DOSVIG: "+ex.Message);}
 }
}
